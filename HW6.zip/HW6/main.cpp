#include <iostream>
#include <random>
#include <sys/time.h>
using namespace std;

#include "Board.h"

int restartGame(char c, Board &B) {
  switch (c) {
    case 'y':case 'Y':
      B.reset();
      return 1;
    case 'n':case 'N':
      return 0;
  }
  return 0;
}

int main(){ 
  char yn;
  string human_string;   
  srand(time(NULL));

  cout << "Welcome to the game of Hex!" << endl;
  Board B(3);
  hexAI jim(B);

  while (true) {
    
    cout << "\nEnter your next move \"x,y\" (or type \"q\" to quit): ";
    cin >> human_string;
    if (human_string == "q") break;

    // Put a new piece on the board and handle any illegal moves.
    try {
      B.stringMove(P1, human_string);
    } catch (int e) {
      switch (e) {
        case 1:
          cout << "Bad Coordinates! Please try again." << endl;
          break;
        case 2:
          cout << "Used coordinates. Please try again." << endl;
          break;
      }
    }

    cout << "Computing next move..." << endl;    
    B.stringMove(P2,jim.play(B));
    //cout << "Number of plays: " << jim.get_num_plays() << endl;

    cout << B << endl;

    //cout << "B.FindWinner(P1): " << B.FindWinner(P1) << endl;
    // Check if there's a winner
    if (B.FindWinner(P1) == true) {
      cout << "\nYou won! Play again? Press(y/n)" << endl;
      cin >> yn;
      if (!restartGame(yn, B)) break;
    }else{
       //cout << "B.FindWinner(P1): false" << endl;
    }     
    if (B.FindWinner(P2) == true) {
      cout << "\nYou lost! Play again? Press(y/n)" << endl;
      cin >> yn;
      if (!restartGame(yn, B)) break;
    }
    //cout << "B.FindWinner(P1): " << B.FindWinner(P1) << endl;

  }

   return 0;
   
}
