#include "ClientSocket.h"
#include "SocketException.h"
#include <iostream>
#include <string>
#include <sys/time.h>
#include <random>
#include <algorithm>
#include <vector>
 
using namespace std;
#include "Board.h"

int restartGame(char c, Board &B) {
  switch (c) {
    case 'y':case 'Y':
      B.reset();
      return 1;
    case 'n':case 'N':
      return 0;
  }
  return 0;
}


bool finish(Board &G, EDGECOLOR color,vector<EDGECOLOR> &color_tag){
  srand(unsigned(time(NULL)));
  vector< vector<edge> > M = G.get_matrix();
  // shuffles all the entries in the array to simulate moves
  random_shuffle(color_tag.begin(), color_tag.end());
  int i = 0; 
  for(int x = 0; x < G.GetSize(); ++x){
    for(int y = 0; y < G.GetSize(); ++y){
      if((M[x][y].get_node() == 3000) 
             && (i < G.GetSize() * G.GetSize())) {
        G.setColor(x,y,color_tag[i]);
        G.setNode(x,y);
        i++;
      }
    }
  }
  return G.FindWinner(color);
}

bool did_we_win(Board &G, EDGECOLOR color){
  Board A = G;
  int wins_P1 = 0;
  int wins_P2 = 0;
  const int trials = 100;

  //creates verctor full of colors that will be shuffel later
  vector<EDGECOLOR> color_tag;
  for (int i = 0; i < (G.GetSize()*G.GetSize()); i++) {
    if (i < ((G.GetSize()*G.GetSize())/ 2)){
      color_tag.push_back(P1);
    } else {
      color_tag.push_back(P2);
    }
  }

  //Go through the board
  for(int x = 0; x < trials; x++){
    A = G;
    //A.makeMove(P2,i,j);
    // Checks if P1 wins, keeps track of how often
    if(finish(A, color, color_tag) == true){
      wins_P1++;  // keeps track of P1 wins, increments
    } else {
      wins_P2++;  // keeps track of P2 wins
    }
  }
  if(wins_P1 == trials){
    return true;
  }
  return false;
}


char enter_input(Board &B, string &human_string){
        cin >> human_string;
        if (human_string == "q") return 'q';
        //make and send moves
        try{
          B.stringMove(P1, human_string);
        } catch (int e) {
          switch (e) {
            case 1:
              cout << "Bad Coordinates! Please try again." << endl;
              //nter_input(B, human_string);
              return enter_input(B, human_string);
            case 2:
              cout << "Used coordinates. Please try again." << endl;
              //enter_input(B, human_string);
              return enter_input(B, human_string);
          }
       } 
  return 'g';
}


int main (){
  cout << "Hello, Welcome to the game of Hex!" << endl;
  cout << "Top corner: (0,0) and Bottom Right Corner (10,10)" << endl;
  
  char yn;
  string human_string;  
  Board B(11);
  cout << B << endl;
  int i = 0;
  //main while loop for game
  while(true){
    cout << "\nEnter your next move x,y (or type q to quit): ";
    //sets up connection to server
    try{
      ClientSocket client_socket ("localhost", 30000);
      string reply;
      //read user input

        //cin >> human_string;
        //if (human_string == "q") break;

        /**
        //make and send moves
        try{
          B.stringMove(P1, human_string);
        } catch (int e) {
          switch (e) {
            case 1:
              cout << "Bad Coordinates! Please try again." << endl;
              cin >> human_string;
              B.stringMove(P1, human_string);
              break;
            case 2:
              cout << "Used coordinates. Please try again." << endl;
              cin >> human_string;
              B.stringMove(P1, human_string);
              break;
          }
       }
**/    
       if (enter_input(B, human_string) == 'q'){
         reply = 'q';
         client_socket << reply;
         break;
       }

       client_socket << human_string;   // send client message to server
       cout << "Waiting for AI to return move..." << endl;        
       client_socket >> reply; // receive response from server
       //if(reply != "Game Over"){
         B.stringMove(P2, reply);
       //}else{
       //  cout << "Game Over" << endl;
       //}
       //cout << B << endl;
     cout << "We received this move from the server:\n\"";
     cout << reply << "\"\n" << std::endl;
     cout << B << endl;
     //cout << "FindWinner(P1): " << B.FindWinner(P1) << endl;
     if(did_we_win(B,P1)){
       cout << "******************************************" << endl;
       cout << "                You Won!" << endl;
       cout << "******************************************" << endl;
       client_socket << "Done";
       break;
     }
     if(did_we_win(B,P2)){
       cout << "------------------------------------------" << endl;
       cout << "                You Lost!" << endl;
       cout << "------------------------------------------" << endl;
       client_socket << "Done";
       break;
     }
     } catch ( SocketException& e ){
       cout << "Exception was caught:" << e.description() << "\n";
     }
  }

  return 0;
}
