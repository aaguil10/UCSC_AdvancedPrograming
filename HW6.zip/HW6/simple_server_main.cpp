#include "ServerSocket.h"
#include "SocketException.h"
#include <string>
#include <iostream>
#include <vector>
#include <random>

using namespace std;

//#include "Board.h"
#include "hexAI.h"

int main (){
  std::cout << "running!....\n";
  int if_lost = 0; 
  try{
    // Create the socket
    ServerSocket server(30000);
    int i = 0;
    Board B(11);
    hexAI jim(B);
    string move;
    //main while loop
    while ( true ){
      ServerSocket new_sock;
      server.accept (new_sock);
      try{
        while ( true ){
          //get move from client
          std::string data;
          new_sock >> data;
          std::cout << "Data Recieved: " << data << std::endl;
          if(data == "q" || data == "Done"){
            exit(0);
          }
          //update board
          B.stringMove(P1,data);
          cout << B << endl;
          //compute and send move to client
          move = jim.play(B);
          if (move == "0,0"){
            if_lost++;
          }
          if(if_lost < 2){
            B.stringMove(P2, move);
            new_sock << move;
          } else {
            new_sock << "Game Over";
          }
        }
      } catch ( SocketException& ) {}
    }
  
  } catch ( SocketException& e ) {
    std::cout << "Exception was caught:" << e.description() << "\nExiting.\n";
  }

  return 0;
}
